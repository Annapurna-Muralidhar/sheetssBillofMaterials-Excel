const cds = require('@sap/cds');

module.exports = cds.service.impl(async function () {
    const { SalesOrderBOM, BOMItems } = this.entities;

    // Handle creating a SalesOrderBOM item
    this.on('CREATE', SalesOrderBOM, async (req) => {
        const { data } = req;
        
        // Make sure BOMItems exist before inserting
        if (data.BOMItems && data.BOMItems.length > 0) {
            await INSERT.into(SalesOrderBOM).entries(data);
            
            // After insert, handle BOMItems
            for (let bomItem of data.BOMItems) {
                await INSERT.into(BOMItems).entries(bomItem);
            }
            
            return { message: 'Sales Order BOM and BOM Items inserted successfully!' };
        }
        
        return { message: 'BOM Items are required for the Sales Order BOM.' };
    });
});
