sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "salesorderbom/libs/style"
], function (Controller, MessageToast, JSONModel, style) {
    "use strict";

    return Controller.extend("salesorderbom.controller.UploadData", {

        onUploadDialogPress: function () {
            var oFileUploader = this.byId("fileUploader");
            var oFileUploaderInput = document.getElementById(oFileUploader.getId() + "-fu");
            var file = oFileUploaderInput.files[0];
            var that = this;
        
            if (file) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    var data = e.target.result;
                    var workbook = XLSX.read(data, { type: 'binary' });
        
                    // Process first sheet for SalesOrderBOM
                    var sheet1 = workbook.Sheets[workbook.SheetNames[0]];
                    var sheet1Data = XLSX.utils.sheet_to_json(sheet1, { header: 1 }).slice(1).map(row => ({
                        ref_id: row[0] || '',
                        BillOfMaterialCategory: row[1] || '',
                        BillOfMaterialVariant: row[2] || '',
                        Material: row[3] || '',
                        Plant: row[4] || '',
                        SalesOrder: row[5] || '',
                        SalesOrderItem: row[6] || '',
                        BillOfMaterialVariantUsage: row[7] || '',
                        BOMHeaderInternalChangeCount: row[8] || '',
                        BOMHeaderText: row[9] || '',
                        BillOfMaterialStatus: row[10] || '',
                        BOMHeaderBaseUnit: row[11] || '',
                        BOMHeaderQuantityInBaseUnit: row[12] || ''
                    }));
        
                    // Process second sheet for SalesOrderBOMItems (BOMItems)
                    var sheet2 = workbook.Sheets[workbook.SheetNames[1]];
                    var sheet2Data = XLSX.utils.sheet_to_json(sheet2, { header: 1 }).slice(1).map(row => ({
                        ref_id: row[0] || '',
                        BillOfMaterialItemNodeNumber: row[1] || '',
                        Material: row[2] || '',
                        Plant: row[3] || '',
                        BOMItemInternalChangeCount: row[4] || '',
                        InheritedNodeNumberForBOMItem: row[5] || '',
                        BillOfMaterialComponent: row[6] || '',
                        BillOfMaterialItemCategory: row[7] || '',
                        BillOfMaterialItemNumber: row[8] || '',
                        BillOfMaterialItemUnit: row[9] || '',
                        BillOfMaterialItemQuantity: row[10] || '',
                        IdentifierBOMItem: row[11] || '',
                        ComponentDescription: row[12] || '',
                        ObjectType: row[13] || '',
                        BOMItemIsCostingRelevant: row[14] || ''
                    }));
        
                    var payload = {
                        sheet1Data: JSON.stringify(sheet1Data),
                        sheet2Data: JSON.stringify(sheet2Data)
                    };
        
                    // Send data to backend OData service
                    $.ajax({
                        url: "/odata/v4/Myservice/SalesOrderBOMData",
                        method: "POST",
                        contentType: "application/json",
                        data: JSON.stringify(payload),
                        success: function (response) {
                            // Check if sheet1Data and sheet2Data are present
                            if (!response || !response.sheet1Data || !response.sheet2Data) {
                                MessageToast.show("Invalid response data from server.");
                                return;
                            }
        
                            // Log response to check the data
                            console.log("Response from backend:", response);
        
                            MessageToast.show("Data imported successfully!");
        
                            // Set the BOM items to the model
                            var oModel = new JSONModel();
                            oModel.setData({
                                sheet1Data: response.sheet1Data,
                                sheet2Data: response.sheet2Data,
                                bomItemsEntries: response.bomItemsEntries // BOM Items
                            });
        
                            // Set the model to the view
                            that.getView().setModel(oModel);
        
                            // Close the dialog
                            var oDialog = that.byId("upload");
                            if (oDialog) {
                                oDialog.close();
                            }
        
                            window.location.reload();
                        },
                        error: function (error) {
                            console.error("Error importing data: ", error);
                            MessageToast.show("Error importing data.");
                        }
                    });
                };
                reader.readAsBinaryString(file);
            } else {
                MessageToast.show("Please choose a file first.");
            }
        },        
        
        onDialogFileChange: function (oEvent) {
            var oSubmitButton = this.byId("Upload");
            oSubmitButton.setEnabled(!!oEvent.getSource().getValue());
        },

        onDialogCancelPress: function () {
            this.byId("upload").close();
        },

        onDialogDownloadPress: function () {
            var wb = XLSX.utils.book_new();

            // Define headers for both sheets
            var wsData1 = [
                ["refID", "Bill Of Material Category", "Bill Of Material Variant", "Material", "Plant", "Sales Order", "Sales Order Item", "Bill Of Material Variant Usage", "BOM Header Internal Change Count", "BOM Header Text", "Bill Of Material Status", "BOM Header Base Unit", "BOM Header Quantity In Base Unit"]
            ];

            var wsData2 = [
                ["refID", "Bill Of Material Item Node Number", "Material", "Plant", "BOM Item Internal Change Count", "Inherited Node Number For BOM Item", "Bill Of Material Component", "Bill Of Material Item Category", "Bill Of Material Item Number", "Bill Of Material Item Unit", "Bill Of Material Item Quantity", "Identifier BOM Item", "Component Description", "Object Type", "BOM Item Is Costing Relevant"]
            ];

            // Create sheets
            var ws1 = XLSX.utils.aoa_to_sheet(wsData1);
            var ws2 = XLSX.utils.aoa_to_sheet(wsData2);

            // Append sheets to the workbook
            XLSX.utils.book_append_sheet(wb, ws1, "SalesOrderBOM");
            XLSX.utils.book_append_sheet(wb, ws2, "SalesOrderBOMItems");

            // Write the workbook to binary string
            var wbout = XLSX.write(wb, { bookType: "xlsx", type: "binary" });

            // Convert binary string to array buffer
            function s2ab(s) {
                var buf = new ArrayBuffer(s.length);
                var view = new Uint8Array(buf);
                for (var i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
                return buf;
            }

            // Create a Blob from the array buffer and trigger download
            var blob = new Blob([s2ab(wbout)], { type: "application/octet-stream" });
            var url = URL.createObjectURL(blob);
            var a = document.createElement("a");
            a.href = url;
            a.download = "bom_template.xlsx";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }
    });
});
