sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'salesorderbom/test/integration/FirstJourney',
		'salesorderbom/test/integration/pages/SalesOrderBOMList',
		'salesorderbom/test/integration/pages/SalesOrderBOMObjectPage',
		'salesorderbom/test/integration/pages/SalesOrderBOM_BOMItemsObjectPage'
    ],
    function(JourneyRunner, opaJourney, SalesOrderBOMList, SalesOrderBOMObjectPage, SalesOrderBOM_BOMItemsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('salesorderbom') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheSalesOrderBOMList: SalesOrderBOMList,
					onTheSalesOrderBOMObjectPage: SalesOrderBOMObjectPage,
					onTheSalesOrderBOM_BOMItemsObjectPage: SalesOrderBOM_BOMItemsObjectPage
                }
            },
            opaJourney.run
        );
    }
);